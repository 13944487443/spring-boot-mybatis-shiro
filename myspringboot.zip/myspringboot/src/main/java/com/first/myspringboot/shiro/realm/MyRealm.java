package com.first.myspringboot.shiro.realm;

import com.first.myspringboot.dao.PermessionMapper;
import com.first.myspringboot.dao.RoleMapper;
import com.first.myspringboot.dao.UserMapper;
import com.first.myspringboot.entity.User;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.Set;

/**
 * @author: 张岩
 * @date: 2019/3/5 0005
 **/
public class MyRealm extends AuthorizingRealm {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private RoleMapper roleMapper;
    @Autowired
    private PermessionMapper permessionMapper;

    /**
     * @Author zhangyan
     * @Description 用来认证权限和角色
     * @Date 上午 11:19 2019/3/5 0005
     * @Param [principalCollection]
     * @return org.apache.shiro.authz.AuthorizationInfo
     **/
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        String username = (String) principalCollection.getPrimaryPrincipal();
        Set<String> roles=roleMapper.selectRoleByUsername(username);
        Set<String> permessions=new HashSet<>();
        for (String str : roles){
            permessions.addAll(permessionMapper.selectPermessionByRole(str));
        }
        SimpleAuthorizationInfo simpleAuthorizationInfo=new SimpleAuthorizationInfo();
        simpleAuthorizationInfo.setRoles(roles);
        simpleAuthorizationInfo.setStringPermissions(permessions);
        return simpleAuthorizationInfo;
    }

    /**
     * @Author zhangyan
     * @Description 用来认证密码
     * @Date 上午 11:21 2019/3/5 0005
     * @Param [authenticationToken]
     * @return org.apache.shiro.authc.AuthenticationInfo
     **/
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {
        String username= (String) authenticationToken.getPrincipal();
        User user=userMapper.selectPasswordByUsername(username);
        if (user==null)
            return null;
        SimpleAuthenticationInfo simpleAuthenticationInfo=new SimpleAuthenticationInfo(username,user.getPassword(),"myRealm");
        simpleAuthenticationInfo.setCredentialsSalt(ByteSource.Util.bytes(user.getSalt()));
        return simpleAuthenticationInfo;
    }
}

