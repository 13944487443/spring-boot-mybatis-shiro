package com.first.myspringboot.controller;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @classname: TestController
 * @description: todo
 * @author: 张岩
 * @date: 2019/3/5 0005
 **/
@RestController
public class TestController {

    @RequiresPermissions("all")
    @RequiresRoles("admin")
    @RequestMapping("test")
    public String test(){
        return "test";
    }
}

