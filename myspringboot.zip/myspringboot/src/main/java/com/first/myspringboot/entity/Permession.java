package com.first.myspringboot.entity;

public class Permession {
    private String id;

    private String role;

    private String permession;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role == null ? null : role.trim();
    }

    public String getPermession() {
        return permession;
    }

    public void setPermession(String permession) {
        this.permession = permession == null ? null : permession.trim();
    }
}