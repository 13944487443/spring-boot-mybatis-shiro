package com.first.myspringboot.dao;

import com.first.myspringboot.entity.Person;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface PersonMapper {
    int deleteByPrimaryKey(String id);

    int insert(Person record);

    int insertSelective(Person record);

    Person selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Person record);

    int updateByPrimaryKey(Person record);

    List<Person> selectAll();
}