package com.first.myspringboot.dao;

import com.first.myspringboot.entity.Permession;
import org.springframework.stereotype.Repository;

import java.util.Set;
@Repository
public interface PermessionMapper {
    int deleteByPrimaryKey(String id);

    int insert(Permession record);

    int insertSelective(Permession record);

    Permession selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Permession record);

    int updateByPrimaryKey(Permession record);

    Set<String> selectPermessionByRole(String role);
}