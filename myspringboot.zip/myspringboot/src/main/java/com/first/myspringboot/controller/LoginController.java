package com.first.myspringboot.controller;

import com.first.myspringboot.entity.User;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


/**
 * @author: 张岩
 * @date: 2019/3/5 0005
 **/
@Controller
public class LoginController {
    @RequestMapping(value = "login",method = RequestMethod.GET)
    public String login(){
        return "login";
    }

    @RequestMapping(value = "login",method = RequestMethod.POST)
    public String login(User user){
        Subject subject=SecurityUtils.getSubject();
        UsernamePasswordToken token=new UsernamePasswordToken(user.getUsername(),user.getPassword());
        subject.login(token);
        return "index";
    }

    @RequiresRoles("admin")
    @RequestMapping("home")
    public String home(){
        return "index";
    }

    @RequestMapping(value = "error",method = RequestMethod.GET)
    @ResponseBody
    public String error(){
        return "error";
    }

}

