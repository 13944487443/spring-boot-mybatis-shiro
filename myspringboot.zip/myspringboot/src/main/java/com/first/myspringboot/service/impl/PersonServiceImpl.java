package com.first.myspringboot.service.impl;

import com.first.myspringboot.dao.PersonMapper;
import com.first.myspringboot.entity.Person;
import com.first.myspringboot.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author: 张岩（afateg）
 * @date: 2019/2/18 0018
 **/
@Service
public class PersonServiceImpl implements PersonService {
    @Autowired
    private PersonMapper personMapper;
    @Override
    public List<Person> selectAll() {
        return personMapper.selectAll();
    }
}

