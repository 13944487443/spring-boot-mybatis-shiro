package com.first.myspringboot.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * @author: 张岩（afateg）
 * @date: 2019/2/20 0020
 **/
@Configuration
public class DataSourceConfig {
    @Value("${druid.jdbcUrl}")
    private String jdbcUrl;
    @Value("${druid.username}")
    private String username;
    @Value("${druid.password}")
    private String password;
    @Value("${druid.driverClassName}")
    private String driverClassName;
    @Value("${druid.initialSize}")
    private String initialSize;
    @Value("${druid.maxActive}")
    private String maxActive;
    @Value("${druid.minIdle}")
    private String minIdle;

    @Bean
    public DataSource dataSource(){
        DruidDataSource dataSource=new DruidDataSource();
        dataSource.setUrl(jdbcUrl);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setDriverClassName(driverClassName);
        dataSource.setInitialSize(Integer.parseInt(initialSize));
        dataSource.setMinIdle(Integer.parseInt(minIdle));
        dataSource.setMaxActive(Integer.parseInt(maxActive));
        return dataSource;
    }
}

