package com.first.myspringboot;

import org.apache.shiro.crypto.hash.Md5Hash;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages = "com.first.myspringboot.dao")
public class MyspringbootApplication {

	public static void main(String[] args) {
		Md5Hash md5Hash=new Md5Hash("123456","加盐");
		System.out.println(md5Hash.toString());
		SpringApplication.run(MyspringbootApplication.class, args);
	}



}
