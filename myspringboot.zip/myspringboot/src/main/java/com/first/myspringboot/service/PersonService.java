package com.first.myspringboot.service;

import com.first.myspringboot.entity.Person;

import java.util.List;

/**
 * @author: 张岩（afateg）
 * @date: 2019/2/18 0018
 **/
public interface PersonService {
    List<Person> selectAll();
}
